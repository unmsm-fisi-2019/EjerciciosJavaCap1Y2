package Capitulo_2;

import java.util.*;

public class fEjercicios_22_24 {
	static Scanner var=new Scanner(System.in);
	//Tarea 2.22 Area de un hexagono regular
	public static void areaHexaRe() {
		float lado;
		try {
			System.out.println("Inserte el lado del hexagono regular :");
			lado=var.nextFloat();
			System.out.printf("Area : %.3f\n",(3*Math.sqrt(3)/2)*lado*lado);
		}catch(InputMismatchException excepcion) {
			System.out.println("Dato no valido");
			var.nextLine();
		}
	}
	//Tarea 2.23 Determina la aceleracion
	public static void valAcel() {
		float v0,vf,t,acel;
		try {
			System.out.println("Inserte la velocidad inicial , final y el tiempo");
			v0=var.nextFloat();
			vf=var.nextFloat();
			t=var.nextFloat();
			System.out.printf("Aceleracion : %.3f\n",(vf-v0)/t);
		}catch(InputMismatchException excepcion) {
			System.out.println("Dato no valido");
			var.nextLine();
		}
	}
	//Tarea 2.24 Longitud de la pista necesaria para el despegue de un avion
	public static void longPista() {
		float vel,ace;
		try {
			System.out.println("Inserte la aceleracion y velocidad");
			vel=var.nextFloat();
			ace=var.nextFloat();
			System.out.printf("Longitud de la pista necesaria : %.3f\n", (vel*vel)/(2*ace));
		}catch(InputMismatchException excepcion) {
			System.out.println("Dato no valido");
			var.nextLine();
		}
	}
	public static void main(String arg[]) {
		System.out.println("Tarea 2.22");
		areaHexaRe();
		System.out.println("\nTarea 2.23");
		valAcel();
		System.out.println("\nTarea 2.24");
		longPista();
	}

}
