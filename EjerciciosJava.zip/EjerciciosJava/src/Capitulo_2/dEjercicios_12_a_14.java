package Capitulo_2;

import java.util.*;

public class dEjercicios_12_a_14 {
	static Scanner var=new Scanner(System.in);
	//Tarea 2.12 Calcula los intereses
	public static void calculoInte() {
		float saldo,interes;
		try {
			System.out.println("Ingrese saldo");
			saldo=var.nextFloat();
			System.out.println("Ingrese el interes anual(%)");
			interes=var.nextFloat();
			saldo=(float)saldo*(interes/1200);
			System.out.printf("Interes : %.3f\n",saldo);
		}catch(InputMismatchException excepcion) {
			System.out.println("Dato no valido");
			var.nextLine();
		}
	}
	//Tarea 2.13 Pide 3 datos (inversion,tasa mensual,a�os) devuelve el valor acumulado
	public static void valAcumu() {
		float inv,tas,year;
		try {
			System.out.println("Ingrese la inversion : ");
			inv=var.nextFloat();
			System.out.println("Ingrese el interes mensual : ");
			tas=var.nextFloat();
			System.out.println("Ingrese el numero de a�os : ");
			year=var.nextFloat();
			inv=(float) (inv*Math.pow(1+tas, year*12));
			System.out.println("Valor acumulado : "+inv);
		}catch(InputMismatchException excepcion) {
			System.out.println("Dato no valido");
			var.nextLine();
		}
	}
	//Tarea 2.14 Calculo de indice de masa corporal
	public static void calMasa() {
		float peso,alto;
		try {
			System.out.println("Inserte el peso en libras");
			peso=var.nextFloat();
			System.out.println("Inserte alto en pulgadas");
			alto=var.nextFloat();
			peso=(float) (0.45359237*peso);
			alto=(float) (alto*0.0254);
			System.out.printf("Indice de masa corporal : %.3f\n",peso/(alto*alto));
			
		}catch(InputMismatchException excepcion) {
			System.out.println("Dato no valido");
			var.nextLine();
		}
	}
	
	public static void main(String arg[]) {
		System.out.println("Tarea 2.12");
		calculoInte();
		System.out.println("\nTarea 2.13");
		valAcumu();
		System.out.println("\nTarea 2.14");
		calMasa();
	}
}
