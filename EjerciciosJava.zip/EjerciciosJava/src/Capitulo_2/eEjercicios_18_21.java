package Capitulo_2;

import java.util.*;

public class eEjercicios_18_21 {
	static Scanner var=new Scanner(System.in);
	//Tarea 2.18 Imprime una tabla
	public static void imprTable() {
			for(int i=0;i<5;i++) {
				System.out.println((i+1)+"	"+(i+2) + "		"+Math.pow(i+1, i+2));
			}
	}
	//Tarea 2.19 Muestra una letra mayuscula random utilizando System.CurrentTimeMillis()
	public static void caracterAzar() {
		int val;
		char car = 0;
		System.out.println("Tiempo en milisegundos : "+System.currentTimeMillis());
		val=(int) (System.currentTimeMillis()%128);
		
		if(val>=65 && val<=90) {
			car=(char)val;
			System.out.println("Caracter : "+car);	
		}else {
			while(val<65) {
				val=val+1;
				car=(char)(val+(int)(Math.random()*25));
			}
			while(val>90) {
				val=val-1;
				car=(char)(val-(int)(Math.random()*25));	
			}
			System.out.println("Caracter : "+car);	
		}
		
	}
	//Tarea 2.20 Distancia de 2 puntos
	public static void distPuntos() {
		float x1,y1,x2,y2,dist_puntos;
		
		try {
			System.out.println("Inserte x1 y y1");
			x1=var.nextFloat();
			y1=var.nextFloat();
			System.out.println("Inserte x2 y y2");
			x2=var.nextFloat();
			y2=var.nextFloat();
			dist_puntos=(float)(Math.sqrt(Math.pow(x1-x2,2)+Math.pow(y1-y2, 2)));
			System.out.println("Distancia : " + dist_puntos);
		}catch(InputMismatchException excepcion) {
			System.out.println("Dato no valido");
			var.nextLine();
		}
	}
	//Tarea 2.21 Area de un triangulo dado 3 puntos
	public static void areaPuntos() {
		float x1,x2,x3,y1,y2,y3,side1,side2,side3,side,area;
		try {
			System.out.println("Inserte los 3 puntos (x1,y1,x2,y2,x3,y3)");
			x1=var.nextFloat();
			y1=var.nextFloat();
			x2=var.nextFloat();
			y2=var.nextFloat();
			x3=var.nextFloat();
			y3=var.nextFloat();
			side1=(float)(Math.sqrt(Math.pow(x1-x2,2)+Math.pow(y1-y2, 2)));
			side2=(float)(Math.sqrt(Math.pow(x1-x3,2)+Math.pow(y1-y3, 2)));
			side3=(float)(Math.sqrt(Math.pow(x2-x3,2)+Math.pow(y2-y3, 2)));
			side=(float)((side1+side2+side3)/2);
			System.out.println("Lado 1 : "+side1);
			System.out.println("Lado 2 : "+side2);
			System.out.println("Lado 3 : "+side3);

			area=(float) (Math.sqrt(side*(side-side1)*(side-side2)*(side-side3)));
			System.out.println("Area : "+area);
		}catch(InputMismatchException excepcion) {
			System.out.println("Dato no valido");
			var.nextLine();
		}
	}
	public static void main(String arg[]) {
		System.out.println("Tarea 2.18");
		imprTable();
		System.out.println("\nTarea 2.19");
		caracterAzar();
		System.out.println("\nTarea 2.20");
		distPuntos();
		System.out.println("\nTarea 2.21");
		areaPuntos();
	}
	
}
