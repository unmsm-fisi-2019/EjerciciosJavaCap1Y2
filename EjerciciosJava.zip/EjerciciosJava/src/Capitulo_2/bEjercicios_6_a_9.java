package Capitulo_2;
import java.util.*;
public class bEjercicios_6_a_9 {
	
	static Scanner var=new Scanner(System.in);
	//Tarea 2.6 Ingresa un numero de 0 a 1000 y suma sus digitos
	public static void sumaDigi() {
		int valor,suma=0;
		try {
			do {
				System.out.println("Inserte un valor (0-1000)");
				valor=var.nextInt();
				if(valor<0 || valor>1000) {
					System.out.println("Valor fuera del rango, vuelva a intentar");
				}
			}while(valor<0 || valor>1000);
			while(valor>0) {
				suma=(int)suma+valor%10;
				valor=valor/10;		
			}
			System.out.println("Suma de digitos : "+suma);
			
		}catch(InputMismatchException excepcion) {
			System.out.println("Dato no permitido");	
			var.nextLine();
		}
		
	}
	//Tarea 2.7 Ingresa cantidad de minutos y devuelve a�os y dias
	public static void fechaMinutos() {
		int valor,year,days;
		try {
			do {
				System.out.println("Inserte minutos : ");
				valor=var.nextInt();
				if(valor<0) {
					System.out.println("No puede ser negativo, vuelva a intentar");
				}
			}while(valor<0);
			year=valor/(365*24*60);
			days=(valor%(365*24*60))/(60*24);
			System.out.println("A�os : "+year);
			System.out.println("Dias : "+days);
		}catch(InputMismatchException excepcion) {
			System.out.println("Dato no permitido");	
			var.nextLine();
		}
	}
	//Tarea 2.8 Convierte un numero de 0 a 128 es un ASCII
	public static void codigosASCII() {
		char car;
		int valor;
		try {
			do {
				System.out.println("Inserte codigo ASCII(0-128) : ");
				valor=var.nextInt();
				if(valor<0 || valor>128) {
					System.out.println("No puede ser negativo, vuelva a intentar");
				}
				car=(char)valor;
			}while(valor<0 || valor>128);
			System.out.println("Caracter ASCII : "+car);
		}catch(InputMismatchException excepcion) {
			System.out.println("Dato no permitido");	
			var.nextLine();
		}
	}
	//Tarea 2.9 Da un numero y los 2 ultimos valores son centavos y el resto dolares
	public static void convertirValor() {
		int valor,ult;
		try{
			System.out.println("Inserte un numero entero");
			valor=var.nextInt();
			ult=valor/100;
			valor=valor-(ult*100);
			System.out.println("Dolares : "+ult);
			System.out.println("Centavos : "+valor); 
		
		}catch(InputMismatchException excepcion) {
			System.out.println("Dato no permitido");	
			var.nextLine();
		}
	}
	
	public static void main(String arg[]) {
		System.out.println("Tarea 2.6");
		sumaDigi();
		System.out.println("\nTarea 2.7");
		fechaMinutos();
		System.out.println("\nTarea 2.8");
		codigosASCII();
		System.out.println("\nTarea 2.9");
		convertirValor();
	}

}
