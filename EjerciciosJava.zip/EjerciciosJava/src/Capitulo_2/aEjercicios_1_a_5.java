package Capitulo_2;

import java.util.*;

public class aEjercicios_1_a_5 {
	static Scanner var=new Scanner(System.in);
	//Tarea 2.1 Ingresa en Celsius y convierte a Fahrenheir
		public static void celsiusToFahrenheit() {
			float far=0,cel;
			System.out.print("Ingrese una cantidad en Celsius : ");
			
			try {
				cel=var.nextFloat();
				far=(float) (9.0/5)*cel+32;
				System.out.println(cel + " Celsius equivale a "+far+" Fahrenheit");
					
			}catch(InputMismatchException excepcion) {
				System.out.println("Dato no valido");
				var.nextLine();
			}
		}
		
	//Tarea 2.2 Lee el radio y la logitud de un cilindro, devuelve el volumen y area
		public static void medidasCilindro() {
			final double PI = 3.141592;
			float rad,longitud;
			try {
				System.out.print("Inserte el radio : ");
				rad=var.nextFloat();
				System.out.print("Ingrese la longitud : ");
				longitud=var.nextFloat();
				System.out.printf("Area : %.4f\n",(rad*rad*PI));
				System.out.printf("Volumen : %.4f\n",(rad*rad*longitud*PI));
				
			}catch(InputMismatchException excepcion) {
				System.out.println("Dato no valido");
				var.nextLine();
			}
		}

	//Tarea 2.3 Convierte los pies en metos
		public static void piesToMetros() {
			float pies;
			try {
				System.out.print("Ingrese la cantidad de pies : ");
				pies=var.nextFloat();
				System.out.printf("%.4f %s %.4f %s \n", pies , " pies equivale a ",(pies*0.305)," metros");
			}catch(InputMismatchException excepcion) {
				System.out.println("Dato no valido");
				var.nextLine();
			}
		}
		
	//Tarea 2.4  Convierte libras en kilogramos
		
		public static void libraToKilo() {
			float libras;
			try {
				System.out.print("Ingrese la cantidad de libras : ");
				libras=var.nextFloat();
				System.out.printf("%.4f %s %.4f %s \n", libras , " libras equivale a ",(libras*0.454)," kilogramos");
			}catch(InputMismatchException excepcion) {
				System.out.println("Dato no valido");
				var.nextLine();
			}
		}
	//Tarea 2.5 Pide subtotal y tasa de propinas y devuelve 
		public static void PropinaYSubtotal() {
			float propina,subtotal,total;
			try {
				System.out.print("Ingrese el SUBTOTAL y la PROPINA :  ");
				subtotal=var.nextFloat();
				propina=var.nextFloat();
				total=subtotal*propina/100;
				System.out.printf("Propina : %.3f\n",total);
				total=total+subtotal;
				System.out.printf("Total : %.3f\n",total);
			}catch(InputMismatchException excepcion) {
				System.out.println("Dato no valido");
				var.nextLine();
			}
		}
		
		public static void main(String arg[]) {
			System.out.println("Tarea 2.1");
			celsiusToFahrenheit();
			System.out.println("\nTarea 2.2");
			medidasCilindro();
			System.out.println("\nTarea 2.3");
			piesToMetros();
			System.out.println("\nTarea 2.4");
			libraToKilo();	
			System.out.println("\nTarea 2.5");
			PropinaYSubtotal();
		}
}
