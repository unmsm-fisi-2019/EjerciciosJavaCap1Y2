package Capitulo_2;

import java.util.*;

public class cEjercicios_11 {
	//Tarea 2.11 Pide datos del empleados y el porcentaje que paga de impuestos y calcula el sueldo neto
	public static void main(String arg[]) {
		Scanner var=new Scanner(System.in);
		
		int horas;
		float pago_horas,imp_fe,imp_sta,imp_tot,pago_bruto;
		String name;
		try{
		
		System.out.println("Inserte los sgt. datos");
		
		System.out.printf("Nombre del empleado : ");
		name=var.nextLine();
		System.out.printf("Numeros de horas que trabaja durante una semana : ");
		horas=var.nextInt();
		System.out.printf("Pago por hora : ");
		pago_horas=var.nextFloat();
		System.out.printf("Impuestos federales(0 - 0,5) : ");
		imp_fe=var.nextFloat();
		System.out.printf("Impuestos estatales(0 - 0,5) : ");
		imp_sta=var.nextFloat();
		pago_bruto=(float)horas*pago_horas;

		System.out.println("********************************");
		System.out.printf("Empleado : %s\n",name);
		System.out.printf("Horas semanales : %d\n",horas);
		System.out.printf("Sueldo bruto : %.3f\n",pago_bruto);
		
		System.out.println("DEDUCCIONES : ");
		imp_tot=(float) (pago_bruto*20.0/100);
		System.out.printf("	Impuestos federales  : %.3f\n",imp_tot);
		imp_tot=(float) (pago_bruto*9.0/100);
		System.out.printf("	Impuestos estatales : %.3f\n",imp_tot);
		imp_tot=(float)(pago_bruto*29/100);
		System.out.printf("	Deduciones totales : %.3f\n",imp_tot);
		System.out.printf("Sueldo neto : %.3f",pago_bruto-imp_tot);

		}catch(InputMismatchException excepcion) {
			System.out.println("Dato no permitido");	
			var.nextLine();
		}
	}

}
