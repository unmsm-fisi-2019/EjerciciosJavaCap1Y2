package Capitulo_1;

public class Ejercicios_1_a_7 {
//Tarea 1.1 muestra 3 mensages
	public static void threeMessages() {
		System.out.println("Welcome to Java");
		System.out.println("Welcome to Computer Science");
		System.out.println("Programming is fun");
	}

//Tarea 1.2 muestra 5 mensages
	public static void fiveMessages() {
		for(int i=0;i<5;i++) {
			System.out.println("Welcome to Java");
		}
	}
//Tarea 1.3 imprime un patron
	public static void Patron() {
		System.out.println("    J     A     V     V     A    ");
		System.out.println("    J    A A     V   V     A A   ");
		System.out.println("J   J   AAAAA     V V     AAAAA  ");
		System.out.println(" J J   A     A     V     A     A ");

	}
//Tarea 1.4 imprime una tabla
	public static void Tabla() {
		for(int i=0;i<4;i++) {
			System.out.println((i+1)+"	"+((i+1)*(i+1))+"	"+((i+1)*(i+1)));
		}
	}
//Tarea 1.5 Muestra el resultado de una operacion
	public static float Operacion() {
		float val;
		val=(float)((9.5*4.5-2.5*3)/(45.5-3.5));
		return val;
	}
//Tarea 1.6 resultado de sumar 1+2...+9
	public static void sumaSerie() {
		System.out.println("Suma de la serie : "+(1+2+3+4+5+6+7+8+9));
	}
//Tarea 1.7 aproxima el valor de pi
	public static float aproxPi() {
		float aprox;
		aprox=(float)(1.0*(4.0-1/3.0+1/5.0-1/7.0+1/9.0-1/11.0+1/13.0));
		return aprox;
	}

		
		public static void main(String arg[]) {
			System.out.println("Tarea 1.1");
			threeMessages();
			System.out.println("\nTarea 1.2");
			fiveMessages();
			System.out.println("\nTarea 1.3");
			Patron();
			System.out.println("\nTarea 1.4");
			Tabla();
			System.out.println("\nTarea 1.5");
			System.out.println("Resultado : "+Operacion());
			System.out.println("\nTarea 1.6");
			sumaSerie();
			System.out.println("\nTarea 1.7");
			System.out.println("Valor aproximado de Pi : "+aproxPi());
		}

}
